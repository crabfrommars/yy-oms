/**

 @Name：layuiAdmin 工单系统
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：GPL-2

 */


layui.define(['table', 'form', 'element'], function (exports) {
    var $ = layui.$
        , table = layui.table
        , form = layui.form
        , element = layui.element;

    table.render({
        elem: '#LAY-app-system-order'
        , url: '/index/order/order'
        , cols: [[
            {field: 'id', title: '编号', width: 60, fixed: 'left', align: 'center'},
            {field: 'this_t6', title: 'T6号', width: 70, align: 'center'},
            {title: '工厂', width:70, align: 'center', templet:'#factory'},
            {field: 'order_type', title: '类型', width: 75, align: 'center', templet: '#order_typeTpl'},
            {field: 'progress',event:'record', style:'cursor: pointer', title: '进度', width: 150, align: 'center', templet: '#progressTpl'},
            {field: 'customer', title: '客户', width:180  },
            {field: 'salesman', title: '业务员', width: 75, align: 'center'},
            {field: 'model', title: '型号', width: 180},
            {field: 'quantity', title: '数量', width: 60, align: 'center'},
            {field: 'current_content', title: '当前工作',width:120, align:'left'},
            {title: '当前人员', width: 95, align: 'center',fixed:'right',templet:'#current_roleTpl'},
            {title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-system-order'}
        ]]
        , page: {
            limit:20
            , limits:[10,20,30,40,50]
            , groups:5
        }
        , text: '对不起，加载出现异常！'
        , done: function () {
            element.render('progress')
        }
    });

    //监听工具条
    table.on('tool(LAY-app-system-order)', function (obj) {

        if (obj.event === 'progress') {
            // console.log(obj.data.id);
            layer.open({
                type:2
                , title:'流程操作'
                , content:'/index/order/progressform?id='+obj.data.id
                , area:['450px','500px']
                , btn:['提交','取消']
                , btnAlign:'c'
                , yes:function (index,layero) {
                    let body = layer.getChildFrame('body', index)
                        , iframeWindow = window['layui-layer-iframe' + index]
                        , submitID = 'submit'
                        , submit = layero.find('iframe').contents().find('#' + submitID);

                    iframeWindow.layui.form.on('submit('+submitID+')',function (data) {
                        let field=data.field;
                        if (field.current == '100%'){
                            layer.msg('订单已完成，无法继续流转')
                        } else if (field.current == field.progress){
                            layer.msg('流转目标与当前重复，请检查')
                        } else {
                            $.ajax({
                                url:'/index/order/canEdt'
                                , data:{
                                    'progress':field.current
                                }
                                , type:'POST'
                                , success:(res)=>{
                                    if (res){
                                        $.ajax({
                                            type:'POST',
                                            url:'/index/order/updateP',
                                            data:field,
                                            success:(res)=>{
                                                layer.msg(res.msg);
                                                table.reload('LAY-app-system-order');
                                            }
                                        });

                                        layer.close(index);
                                    } else {
                                        layer.msg('你当前无权进行该操作',{icon:2});
                                    }
                                }
                            });
                        }
                    });

                    submit.trigger('click');
                }
            })
        }else if (obj.event === 'record'){
            layer.open({
                type:2
                , title:'历史记录'
                , content:'/index/order/history?id='+obj.data.id
                , area:['450px','500px']
                , btn:['确定']
                , btnAlign:'c'
            })
        }else if (obj.event === 'senior'){
            layer.open({
                type:2
                , title:'高级'
                , content:'/index/order/senior?id='+obj.data.id
                , area:['450px','500px']
                , btn:['确定']
                , btnAlign:'c'
            })
        }
    });

    //监听行事件
    table.on('rowDouble(LAY-app-system-order)',function(obj){
      let data = obj.data;
      let win=layer.open({
          type: 2
          , title: '编辑订单'
          , content: '/index/order/listform?id='+data.id
          , area: ['500px', '450px']
          , maxmin:true
      });
      layer.full(win);
    });

    exports('workorder', {})
});
