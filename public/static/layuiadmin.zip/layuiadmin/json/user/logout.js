{
  "code": 0
  ,"msg": "退出成功"
  ,"data": null
}